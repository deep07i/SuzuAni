from suzuani import create_app, db, bcrypt
from suzuani.models import User

def setup_database():
    """Database tables aur admin user banata hai."""
    app = create_app()
    with app.app_context():
        print("Creating database tables...")
        db.create_all()
        print("Database tables created successfully!")

        print("Creating the first admin user...")
        hashed_password = bcrypt.generate_password_hash('password').decode('utf-8')
        admin_user = User.query.filter_by(email='admin@suzuani.com').first()
        
        if not admin_user:
            admin_user = User(name='Admin', username='admin', email='admin@suzuani.com', password=hashed_password, is_admin=True)
            db.session.add(admin_user)
            db.session.commit()
            print("Admin user created! (Email: admin@suzuani.com, Password: password)")
        else:
            print("Admin user already exists.")

if __name__ == '__main__':
    setup_database()