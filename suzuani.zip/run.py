from suzuani import create_app

# We create an instance of our app using the factory function
app = create_app()

# This block ensures the server only runs when the script is executed directly
# It also enables debug mode for helpful error messages during development
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')