import os
# --- YAHAN BADLAAV KIYA GAYA HAI ---
from flask import Flask, redirect, url_for, request
from markupsafe import Markup
# ------------------------------------
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_bcrypt import Bcrypt
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView

# Initialize extensions
db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'
admin = Admin(name='Suzuani Admin', template_mode='bootstrap4')

# --- ADVANCED ADMIN VIEWS ---
class SecureAdminView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('login', next=request.url))

class AnimeAdminView(SecureAdminView):
    def _thumbnail_formatter(view, context, model, name):
        if not model.cover_image_url: return ''
        return Markup(f'<img src="{model.cover_image_url}" style="height: 60px; border-radius: 4px;">')
    
    column_formatters = {
        'cover_image_url': _thumbnail_formatter,
        'likes': lambda v, c, m, n: len(m.likes),
        'views': lambda v, c, m, n: len(m.views),
        'comments': lambda v, c, m, n: len(m.comments),
    }
    column_list = ('id', 'title', 'cover_image_url', 'is_featured', 'likes', 'views', 'comments')
    form_columns = ('title', 'description', 'cover_image_url', 'is_featured', 'episodes')
    inline_models = ('episodes',)

class UserAdminView(SecureAdminView):
    column_editable_list = ['name', 'is_admin']
    column_exclude_list = ('password',)
    form_excluded_columns = ('password', 'comments', 'likes')
    column_searchable_list = ('username', 'email', 'name')
    column_list = ('id', 'name', 'username', 'email', 'is_admin')

class CommentAdminView(SecureAdminView):
    can_create = False
    can_edit = True
    can_delete = True
    column_list = ('id', 'author.name', 'anime.title', 'text', 'date_posted')
    column_searchable_list = ('text', 'author.name', 'anime.title')
    
def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'a_very_secret_key'
    project_dir = os.path.dirname(os.path.abspath(os.path.join(__file__, '..')))
    database_file = "sqlite:///{}".format(os.path.join(project_dir, "site.db"))
    app.config['SQLALCHEMY_DATABASE_URI'] = database_file
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/profile_pics')

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    admin.init_app(app)

    with app.app_context():
        from . import routes
        from .models import User, Anime, Episode, Like, Comment, View

        admin.add_view(UserAdminView(User, db.session))
        admin.add_view(AnimeAdminView(Anime, db.session))
        admin.add_view(CommentAdminView(Comment, db.session))
        admin.add_view(SecureAdminView(Like, db.session))
        admin.add_view(SecureAdminView(View, db.session, name="Views"))

        return app