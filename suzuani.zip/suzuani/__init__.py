import os
from flask import Flask, redirect, url_for, request
from markupsafe import Markup
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_bcrypt import Bcrypt
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView

# Initialize extensions globally
db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'
admin = Admin(name='Suzuani Admin', template_mode='bootstrap4')

def create_app():
    """Construct the core application and its components."""
    
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'a_very_secret_key'
    
    # Configure database and upload folder paths
    project_dir = os.path.dirname(os.path.abspath(os.path.join(__file__, '..')))
    database_file = "sqlite:///{}".format(os.path.join(project_dir, "site.db"))
    app.config['SQLALCHEMY_DATABASE_URI'] = database_file
    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/profile_pics')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize extensions with the app instance
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    admin.init_app(app)

    with app.app_context():
        # First, import the routes. This will register all the URLs.
        from . import routes

        # Now, import the models. This is crucial.
        from . import models

        # --- ADMIN PANEL SETUP (The Correct Way) ---
        # Define Admin views AFTER all models are known and ready.
        
        class SecureAdminView(ModelView):
            def is_accessible(self):
                return current_user.is_authenticated and current_user.is_admin
            def inaccessible_callback(self, name, **kwargs):
                return redirect(url_for('login', next=request.url))

        class AnimeAdminView(SecureAdminView):
            def _thumbnail_formatter(view, context, model, name):
                if not model.cover_image_url: return ''
                return Markup(f'<img src="{model.cover_image_url}" style="height: 60px; border-radius: 4px;">')
            
            column_formatters = { 'cover_image_url': _thumbnail_formatter,
                                  'likes': lambda v, c, m, n: len(m.likes),
                                  'views': lambda v, c, m, n: len(m.views),
                                  'comments': lambda v, c, m, n: len(m.comments) }
            
            column_list = ('id', 'title', 'cover_image_url', 'is_featured', 'likes', 'views', 'comments')
            # We are using the simplified form without inline models to guarantee it works
            form_columns = ('title', 'description', 'cover_image_url', 'is_featured')

        class UserAdminView(SecureAdminView):
            column_editable_list = ['name', 'is_admin']
            column_exclude_list = ('password',)
            form_excluded_columns = ('password', 'comments', 'likes')
            column_searchable_list = ('username', 'email', 'name')
            column_list = ('id', 'name', 'username', 'email', 'is_admin')

        class CommentAdminView(SecureAdminView):
            can_create = False
            can_edit = True
            can_delete = True
            column_list = ('id', 'author.name', 'anime.title', 'text', 'date_posted')
            column_searchable_list = ('text', 'author.name', 'anime.title')
        
        # Add all views to the admin panel
        admin.add_view(UserAdminView(models.User, db.session))
        admin.add_view(AnimeAdminView(models.Anime, db.session))
        admin.add_view(SecureAdminView(models.Episode, db.session)) # Simple view for Episodes
        admin.add_view(CommentAdminView(models.Comment, db.session))
        admin.add_view(SecureAdminView(models.Like, db.session))
        admin.add_view(SecureAdminView(models.View, db.session, name="Views"))

    return app