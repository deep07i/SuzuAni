import os
from flask import Flask, redirect, url_for, request
from markupsafe import Markup
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_bcrypt import Bcrypt
from flask_admin import Admin, AdminIndexView, expose
from flask_admin.contrib.sqla import ModelView

# Initialize extensions globally
db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

class SuzuaniAdminIndexView(AdminIndexView):
    @expose('/')
    def index(self):
        if not current_user.is_authenticated or not current_user.is_admin:
            return redirect(url_for('login'))
        return super(SzuaniAdminIndexView, self).index()

admin = Admin(name='Suzuani Admin', template_mode='bootstrap3', index_view=SuzuaniAdminIndexView())

def create_app():
    """Construct the core application and its components."""
    
    # --- THE GUARANTEED FIX IS HERE ---
    # We are explicitly telling Flask where to find the static and template folders.
    # This removes all ambiguity.
    app = Flask(__name__, 
                instance_relative_config=False,
                static_folder='static',
                template_folder='templates')
    
    app.config.from_mapping(
        SECRET_KEY='a_very_secret_key',
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        UPLOAD_FOLDER=os.path.join(app.static_folder, 'profile_pics')
    )
    
    # Configure database path with an absolute path
    project_dir = os.path.dirname(os.path.abspath(os.path.join(__file__, '..')))
    database_file = "sqlite:///{}".format(os.path.join(project_dir, "site.db"))
    app.config['SQLALCHEMY_DATABASE_URI'] = database_file

    # Initialize extensions with the app instance
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    admin.init_app(app)

    with app.app_context():
        # Import routes and models
        from . import routes
        from . import models

        # --- ADMIN PANEL SETUP (The stable, simplified version) ---
        
        class SecureAdminView(ModelView):
            def is_accessible(self):
                return current_user.is_authenticated and current_user.is_admin
            def inaccessible_callback(self, name, **kwargs):
                return redirect(url_for('login', next=request.url))

        class AnimeAdminView(SecureAdminView):
            column_list = ('id', 'title', 'is_featured')
            form_columns = ('title', 'description', 'cover_image_url', 'is_featured')
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-film'

        class UserAdminView(SecureAdminView):
            column_editable_list = ['name', 'is_admin']
            column_exclude_list = ('password',)
            form_excluded_columns = ('password', 'comments', 'likes', 'views')
            column_searchable_list = ('username', 'email', 'name')
            column_list = ('id', 'name', 'username', 'email', 'is_admin')
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-user'
            
        class CommentAdminView(SecureAdminView):
            can_create = False
            can_edit = True
            can_delete = True
            column_list = ('id', 'author.name', 'anime.title', 'text', 'date_posted')
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-comment'
            
        class EpisodeAdminView(SecureAdminView):
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-list-ol'

        class LikeAdminView(SecureAdminView):
            can_create = False
            column_list = ('id', 'author.name', 'anime.title')
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-heart'

        class ViewAdminView(SecureAdminView):
            can_create = False
            column_list = ('id', 'author.name', 'anime.title', 'timestamp')
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-eye'

        # Add all the custom views to the admin panel
        admin.add_view(UserAdminView(models.User, db.session))
        admin.add_view(AnimeAdminView(models.Anime, db.session))
        admin.add_view(EpisodeAdminView(models.Episode, db.session))
        admin.add_view(CommentAdminView(models.Comment, db.session))
        admin.add_view(LikeAdminView(models.Like, db.session))
        admin.add_view(ViewAdminView(models.View, db.session, name="Views"))
    
    return app