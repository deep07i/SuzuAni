import os
from flask import Flask, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_bcrypt import Bcrypt
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView

# Initialize extensions
db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'
admin = Admin(name='Suzuani Admin', template_mode='bootstrap3')

def create_app():
    """Construct the core application."""
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'a_very_secret_key' # Change this in production
    
    # --- FIX #1 (CRITICAL): Use an absolute path for the database ---
    # This finds the correct path to your project folder and creates the database there.
    # It will work on your local machine AND on any hosting server.
    project_dir = os.path.dirname(os.path.abspath(os.path.join(__file__, '..')))
    database_file = "sqlite:///{}".format(os.path.join(project_dir, "site.db"))
    app.config['SQLALCHEMY_DATABASE_URI'] = database_file
    
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Configuration for file uploads
    app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static/profile_pics')

    # Initialize extensions with the app
    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    admin.init_app(app) # Moved here for better organization

    with app.app_context():
        # Import parts of our application
        from . import routes
        from .models import User, Anime, Episode, Like, Comment, View

        # This view will be accessible only to users with is_admin set to True
        class AdminModelView(ModelView):
            def is_accessible(self):
                return current_user.is_authenticated and current_user.is_admin

            def inaccessible_callback(self, name, **kwargs):
                return redirect(url_for('login', next=request.url))

        admin.add_view(AdminModelView(User, db.session))
        admin.add_view(AdminModelView(Anime, db.session))
        admin.add_view(AdminModelView(Episode, db.session))
        admin.add_view(AdminModelView(Like, db.session))
        admin.add_view(AdminModelView(Comment, db.session))
        admin.add_view(AdminModelView(View, db.session))

        # --- FIX #2 (CRITICAL): Removed db.create_all() ---
        # The database should only be created ONCE using a manual command,
        # not every time the application starts.
        # db.create_all()  <-- REMOVED THIS LINE

        return app