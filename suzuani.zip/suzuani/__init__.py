import os
from flask import Flask, redirect, url_for, request
from markupsafe import Markup
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from flask_bcrypt import Bcrypt
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from wtforms import Form

db = SQLAlchemy()
bcrypt = Bcrypt()
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

# --- THEME FOR ADMIN PANEL ---
class SuzuaniAdmin(Admin):
    def __init__(self, *args, **kwargs):
        super(SuzuaniAdmin, self).__init__(*args, **kwargs)
        self.static_url_path = '/static/admin'
        self.add_css_file('css/admin_theme.css')

admin = SuzuaniAdmin(name='Suzuani Admin', template_mode='bootstrap3') # Bootstrap3 works better with this theme

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'a_very_secret_key'
    # ... (baaki ki config waisi hi rahegi) ...

    db.init_app(app)
    bcrypt.init_app(app)
    login_manager.init_app(app)
    admin.init_app(app)

    with app.app_context():
        from . import models

        class SecureAdminView(ModelView):
            # ... (yeh class waisi hi rahegi) ...

        class AnimeAdminView(SecureAdminView):
            # ... (yeh class waisi hi rahegi) ...
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-film'

        class UserAdminView(SecureAdminView):
            # ... (yeh class waisi hi rahegi) ...
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-user'
            
        class CommentAdminView(SecureAdminView):
            # ... (yeh class waisi hi rahegi) ...
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-comment'
            
        class EpisodeAdminView(SecureAdminView): # New simple class for Episodes
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-list-ol'

        class LikeAdminView(SecureAdminView): # New simple class for Likes
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-heart'

        class ViewAdminView(SecureAdminView): # New simple class for Views
            menu_icon_type = 'fa'
            menu_icon_value = 'fa-eye'

        admin.add_view(UserAdminView(models.User, db.session))
        admin.add_view(AnimeAdminView(models.Anime, db.session))
        admin.add_view(EpisodeAdminView(models.Episode, db.session))
        admin.add_view(CommentAdminView(models.Comment, db.session))
        admin.add_view(LikeAdminView(models.Like, db.session))
        admin.add_view(ViewAdminView(models.View, db.session, name="Views"))
    
    return app