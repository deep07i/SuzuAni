import os
import secrets
from PIL import Image
from flask import render_template, url_for, flash, redirect, request
from . import db, bcrypt
from .forms import RegistrationForm, LoginForm, UpdateAccountForm, CommentForm
from .models import User, Anime, Like, Comment, View
from flask_login import login_user, current_user, logout_user, login_required
from flask import current_app as app

def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, f_ext = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + f_ext
    picture_path = os.path.join(app.config['UPLOAD_FOLDER'], picture_fn)

    output_size = (125, 125)
    i = Image.open(form_picture)
    i.thumbnail(output_size)
    i.save(picture_path)

    return picture_fn

@app.route("/")
@app.route("/home")
def index():
    anime_list = Anime.query.all()
    return render_template('index.html', anime_list=anime_list)

@app.route("/anime/<int:anime_id>", methods=['GET', 'POST'])
def anime_detail(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    
    # Track view
    view = View(anime_id=anime.id, user_id=current_user.id if current_user.is_authenticated else None)
    db.session.add(view)
    db.session.commit()

    # Comment Form
    form = CommentForm()
    if form.validate_on_submit():
        if not current_user.is_authenticated:
            flash('You need to be logged in to comment.', 'info')
            return redirect(url_for('login'))
        comment = Comment(text=form.text.data, author=current_user, anime=anime)
        db.session.add(comment)
        db.session.commit()
        flash('Your comment has been posted!', 'success')
        return redirect(url_for('anime_detail', anime_id=anime.id))

    comments = Comment.query.filter_by(anime_id=anime.id).order_by(Comment.date_posted.desc()).all()
    return render_template('anime_detail.html', title=anime.title, anime=anime, form=form, comments=comments)

@app.route("/anime/<int:anime_id>/like", methods=['POST'])
@login_required
def like_anime(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    like = Like.query.filter_by(author=current_user, anime=anime).first()
    if like:
        # User already liked it, so unlike
        db.session.delete(like)
        db.session.commit()
    else:
        # User has not liked it, so like
        like = Like(author=current_user, anime=anime)
        db.session.add(like)
        db.session.commit()
    return redirect(url_for('anime_detail', anime_id=anime.id))

@app.route("/register", methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(name=form.name.data, username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You can now log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route("/login", methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            login_user(user, remember=form.remember.data)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Login Unsuccessful. Please check email and password.', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route("/account", methods=['GET', 'POST'])
@login_required
def account():
    form = UpdateAccountForm()
    if form.validate_on_submit():
        if form.picture.data:
            picture_file = save_picture(form.picture.data)
            current_user.image_file = picture_file
        current_user.name = form.name.data
        current_user.username = form.username.data
        current_user.email = form.email.data
        db.session.commit()
        flash('Your account has been updated!', 'success')
        return redirect(url_for('account'))
    elif request.method == 'GET':
        form.name.data = current_user.name
        form.username.data = current_user.username
        form.email.data = current_user.email
    image_file = url_for('static', filename='profile_pics/' + current_user.image_file)
    return render_template('account.html', title='Account', image_file=image_file, form=form)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404