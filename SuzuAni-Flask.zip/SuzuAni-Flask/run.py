import os
from flask import Flask, render_template, redirect, url_for, flash, request
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, login_user, logout_user, current_user, login_required
from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView
from werkzeug.utils import secure_filename

# App setup
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_super_secret_key_change_this'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///../instance/suzuani.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

# Import models & forms AFTER app is created
from models import db, User, Category, Anime, Banner, Like, Comment
from forms import SignupForm, LoginForm, ProfileUpdateForm, CommentForm

# Initialize extensions
db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login_signup' # Redirect to this page if user is not logged in
login_manager.login_message_category = 'info'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# --- HELPER FUNCTIONS ---
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# --- CUSTOM CLI COMMAND FOR INSTALLATION ---
@app.cli.command("install")
def install():
    """Creates database and default admin user."""
    with app.app_context():
        db.create_all()
        # Check if admin exists
        if User.query.filter_by(is_admin=True).first():
            print("Admin user already exists.")
            return

        hashed_password = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin_user = User(username='admin', email='admin@suzuani.com', password_hash=hashed_password, is_admin=True)
        db.session.add(admin_user)
        
        # Add sample data
        cat1 = Category(name='Shounen')
        cat2 = Category(name='Isekai')
        db.session.add_all([cat1, cat2])
        
        anime1 = Anime(title='Attack on Titan', poster_url='https://upload.wikimedia.org/wikipedia/en/d/d6/Shingeki_no_Kyojin_manga_volume_1.jpg', description='A great anime.', rating=8.8, release_year=2013, watch_link='#', category=cat1)
        db.session.add(anime1)
        
        banner1 = Banner(banner_image_url='https://cdn.wallpapersafari.com/39/99/a2PzCF.jpg', target_anime=anime1)
        db.session.add(banner1)
        
        db.session.commit()
        print("Database created and admin user 'admin@suzuani.com' with password 'admin123' added.")

# --- ADMIN PANEL SETUP ---
class AdminView(ModelView):
    def is_accessible(self):
        return current_user.is_authenticated and current_user.is_admin
    def inaccessible_callback(self, name, **kwargs):
        return redirect(url_for('login_signup'))

admin = Admin(app, name='SuzuAni Admin', template_mode='bootstrap3')
admin.add_view(AdminView(User, db.session))
admin.add_view(AdminView(Category, db.session))
admin.add_view(AdminView(Anime, db.session))
admin.add_view(AdminView(Banner, db.session))
admin.add_view(AdminView(Comment, db.session))


# --- USER ROUTES ---
@app.route('/')
def home():
    banners = Banner.query.all()
    categories = Category.query.all()
    return render_template('home.html', banners=banners, categories=categories)

@app.route('/anime/<int:anime_id>', methods=['GET', 'POST'])
def anime_details(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    form = CommentForm()
    
    if form.validate_on_submit():
        if not current_user.is_authenticated:
            flash('You must be logged in to comment.', 'info')
            return redirect(url_for('login_signup'))
        comment = Comment(text=form.text.data, author=current_user, anime=anime)
        db.session.add(comment)
        db.session.commit()
        return redirect(url_for('anime_details', anime_id=anime.id))
        
    comments = Comment.query.filter_by(anime_id=anime.id).order_by(Comment.created_at.desc()).all()
    return render_template('anime_details.html', anime=anime, form=form, comments=comments)

@app.route('/like/<int:anime_id>', methods=['POST'])
@login_required
def like_anime(anime_id):
    anime = Anime.query.get_or_404(anime_id)
    like = Like.query.filter_by(user_id=current_user.id, anime_id=anime.id).first()
    if like:
        db.session.delete(like)
    else:
        new_like = Like(user_id=current_user.id, anime_id=anime.id)
        db.session.add(new_like)
    db.session.commit()
    return redirect(url_for('anime_details', anime_id=anime.id))
    
@app.route('/login-signup', methods=['GET', 'POST'])
def login_signup():
    if current_user.is_authenticated:
        return redirect(url_for('home'))
    
    login_form = LoginForm()
    signup_form = SignupForm()

    # Handle Login
    if login_form.validate_on_submit() and 'login' in request.form:
        user = User.query.filter_by(email=login_form.email.data).first()
        if user and bcrypt.check_password_hash(user.password_hash, login_form.password.data):
            login_user(user, remember=True)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('home'))
        else:
            flash('Login Unsuccessful. Please check email and password', 'danger')
    
    # Handle Signup
    if signup_form.validate_on_submit() and 'signup' in request.form:
        hashed_password = bcrypt.generate_password_hash(signup_form.password.data).decode('utf-8')
        user = User(username=signup_form.username.data, email=signup_form.email.data, password_hash=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You are now able to log in', 'success')
        return redirect(url_for('login_signup'))

    return render_template('login_signup.html', login_form=login_form, signup_form=signup_form)

@app.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('home'))
    
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    form = ProfileUpdateForm()
    if form.validate_on_submit():
        current_user.username = form.username.data
        if form.profile_photo.data:
            file = form.profile_photo.data
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                # Create a unique filename
                unique_filename = f"user_{current_user.id}_{filename}"
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], unique_filename))
                current_user.profile_photo_url = unique_filename
        db.session.commit()
        flash('Your profile has been updated!', 'success')
        return redirect(url_for('profile'))
    elif request.method == 'GET':
        form.username.data = current_user.username

    return render_template('profile.html', form=form)

@app.route('/search')
def search():
    query = request.args.get('query', '')
    if query:
        results = Anime.query.filter(Anime.title.ilike(f'%{query}%')).all()
    else:
        results = []
    return render_template('search.html', query=query, results=results)
    
@app.route('/categories')
def categories_page():
    categories = Category.query.all()
    return render_template('categories_page.html', categories=categories)


if __name__ == '__main__':
    with app.app_context():
        # Uncomment the line below if you want to create db on first run
        # db.create_all()
        pass
    app.run(debug=True)